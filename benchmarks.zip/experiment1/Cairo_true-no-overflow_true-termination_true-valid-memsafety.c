extern int __VERIFIER_nondet_int(void);

int main()
{
  int x;
	x = __VERIFIER_nondet_int();
	if (x > 0) {
    	while (x != 0) {
	    	x = x - 1;
	    }
	}
	return 0;
}
