extern int __VERIFIER_nondet_int(void);

int main() {
  int x;
  x = __VERIFIER_nondet_int();
  while (x > 0) {
    x = -5*x + 50;
  }
  return 0;
}
