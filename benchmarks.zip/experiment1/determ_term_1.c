int main() {
  int x = -10;
  int y = 1;
  
  while (x != 0) {
    x = x + y;
    y = y + 1;
  }
  return 0;
}
