int main() {
  int x = -36;
  int y = 0;
  
  while (x != 0) {
    x = x + y;
    y = y + 1;
  }
  return 0;
}
