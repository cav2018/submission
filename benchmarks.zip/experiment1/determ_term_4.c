int main() {
  int x = 4;
  int y = -5;
  int z = 1;
  
  while (x + y != z) {
    x = x * -3;
    y = y + 2;
    z = z - 36;
  }
  return 0;
}
