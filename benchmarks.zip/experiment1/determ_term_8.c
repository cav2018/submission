int main()
{
  int a, b, c, d, e, f;
  a = 0;
  b = 0;
  c = 0;
  d = 0;
  e = 0;
  f = 0;
  
  while (a == 0) {
    a = a + b;
    b = b + c;
    c = c + d;
    d = d + e;
    e = e + f;
    f = f + 1;
  }
  return 0;
}
