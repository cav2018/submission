extern int __VERIFIER_nondet_int(void);

int main()
{
  int d = __VERIFIER_nondet_int();
  int b = __VERIFIER_nondet_int();
  
  while (d * b > 0)
  {
    b = -b;
  }
}
