extern int __VERIFIER_nondet_int(void);

int main()
{
  int j = __VERIFIER_nondet_int();
  int d = __VERIFIER_nondet_int();
  
  while (j > 0 && d > 0)
  {
    if (0 == __VERIFIER_nondet_int())
    {
      j--;
    }
    else
    {
      d--;
    }
  }
}
