int main()
{
  int x = -2;
  int y = 1;
  
  while (x > 0)
  {
    x = x + y;
    y = y + 1;
  }
}
