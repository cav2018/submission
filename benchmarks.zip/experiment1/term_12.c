int main() {
    int i, j, k;
    i = 100;
    j = -1;
    k = 1;
    while (i + j + k >= 1) {
        i = i - 1;
        j = j - 1;
        k = k + 1;
    }  
    return 0;
}
