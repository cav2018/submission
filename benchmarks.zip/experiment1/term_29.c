extern int __VERIFIER_nondet_int(void);

int main()
{
  int x = 0;
  int y = 0;
  int z = 1;
  int N = __VERIFIER_nondet_int();
  
  while (x < N)
  {
    if      (__VERIFIER_nondet_int() == 0 && z == 1) { y = 5; z = 0; }
    else if (__VERIFIER_nondet_int() == 0 && z == 0) { y = -3; z = 1; }
    else if (__VERIFIER_nondet_int() == 0 && z == 1) { y = 7; z = 0; }
    else if (__VERIFIER_nondet_int() == 0 && z == 0) { y = -2; z = 1; }
    else y = 1;

    x = x + y;
  }
}
