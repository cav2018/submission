extern int __VERIFIER_nondet_int(void);

int main()
{
  int x;
  x = __VERIFIER_nondet_int();
  if (x > __VERIFIER_nondet_int()) {
    while (x != 0) {
      x = x - 1;
    }
	}
	return 0;
}
