extern int __VERIFIER_nondet_int(void);

int main() {
  int x, y;
  while (x + y > 0) {
    x = -5*x - 6*y + 18;
  }
  return 0;
}
