int main() {
    int bob;
    int samantha;
    bob = 11;
    samantha = 17;

    while (bob != samantha) {
        int temp = bob;
        bob = max+1;
        max = temp+1;
    }
  
  return 0;
}
