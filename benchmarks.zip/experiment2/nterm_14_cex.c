extern int __VERIFIER_nondet_int(void);

int main()
{
  int j = __VERIFIER_nondet_int();
  int d = __VERIFIER_nondet_int();

  while (d > -4 && j > -4)
  {
    if (0 == __VERIFIER_nondet_int()) j--;
  }
}
