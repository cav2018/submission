extern int __VERIFIER_nondet_int(void);

int main()
{
  int x = 0;

  while (x < 1000)
  {
    if (x != 777) x++;
  }
}
