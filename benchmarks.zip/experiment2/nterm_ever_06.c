extern int __VERIFIER_nondet_int(void);

int main()
{
  int x = 0;
  while (x < 52352)
  {
    x = 37 * (__VERIFIER_nondet_int() % 1415);
  }
}


